
import json
import boto3
import urllib.request
import urllib.error
import urllib.parse
import os
import re

from datetime import datetime, timezone
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['TABLE_NAME'])

translate_client = boto3.client('translate')
comprehend_client = boto3.client('comprehend')

DICTIONARY_API = 'https://freedictionaryapi.com/api/v1'

LANGUAGE_NAMES = {
    'en': 'English',
    'ms': 'Malay',
    'fr': 'French',
    'es': 'Spanish',
    'de': 'German',
    'id': 'Indonesian',
    'zh': 'Chinese',
    'ja': 'Japanese',
    'ko': 'Korean',
    'hi': 'Hindi',
    'ar': 'Arabic'
}


def lambda_handler(event, context):
    try:
        http_context = event.get('requestContext', {}).get('http', {})
        method = http_context.get('method', 'GET')
        path = http_context.get('path', '')

        if method == 'GET' and path.endswith('/dictionary'):
            params = event.get('queryStringParameters') or {}

            word = params.get('word')
            language = params.get('language', 'en')

            if not word or not word.strip():
                return response(400, {
                    'message': 'Please provide a word.'
                })

            word = word.strip()
            language = language.strip().lower()

            if not re.fullmatch(r'[a-z]{2,3}(?:-[a-z]{2,3})*', language):
                return response(400, {
                    'message': 'Invalid language code.'
                })

            return search_word(word, language)

        elif method == 'POST' and path.endswith('/history'):
            params = event.get('queryStringParameters') or {}
            user_id = params.get('userId', 'guest001')

            result = table.query(
                KeyConditionExpression=Key('userId').eq(user_id),
                ScanIndexForward=False,
                Limit=20
            )

            return response(200, {
                'history': result.get('Items', [])
            })

        elif method == 'POST' and path.endswith('/translate'):
            body = event.get('body') or '{}'

            if event.get('isBase64Encoded'):
                import base64
                body = base64.b64decode(body).decode('utf-8')

            try:
                data = json.loads(body)
            except (json.JSONDecodeError, TypeError):
                return response(400, {
                    'message': 'Invalid JSON request body.'
                })

            return translate_text(data)

        else:
            return response(404, {
                'message': 'Route not found.'
            })

    except Exception as e:
        print('Error:', str(e))
        print('Exception type:', type(e).__name__)

        return response(500, {
            'message': 'Internal server error.'
        })


def search_word(word, language):

    encoded_word = urllib.parse.quote(word, safe='')

    url = (
        f'{DICTIONARY_API}/entries/'
        f'{language}/{encoded_word}'
    )

    try:
        req = urllib.request.Request(
            url,
            headers={
                'User-Agent': 'CloudDictionaryApp/2.0',
                'Accept': 'application/json'
            }
        )

        with urllib.request.urlopen(req, timeout=15) as res:
            data = json.loads(res.read().decode())

        entries = data.get('entries', [])

        if not entries:
            return response(404, {
                'message': 'Word not found in this language.'
            })

        meanings = []
        phonetic = ''
        language_name = language

        for entry in entries:

            entry_language = entry.get('language', {})

            if isinstance(entry_language, dict):
                language_name = entry_language.get(
                    'name', language_name
                )

            if not phonetic:
                pronunciations = entry.get(
                    'pronunciations', []
                )

                for pronunciation in pronunciations:
                    if pronunciation.get('type') == 'ipa':
                        phonetic = pronunciation.get('text', '')
                        break

            definitions = []

            for sense in entry.get('senses', []):

                definition_text = sense.get('definition', '')

                if definition_text:
                    definitions.append({
                        'definition': definition_text,
                        'example': (
                            sense.get('examples', [''])[0]
                            if sense.get('examples')
                            else ''
                        ),
                        'synonyms': sense.get('synonyms', []),
                        'antonyms': sense.get('antonyms', [])
                    })

                for subsense in sense.get('subsenses', []):
                    sub_definition = subsense.get(
                        'definition', ''
                    )

                    if sub_definition:
                        definitions.append({
                            'definition': sub_definition,
                            'example': (
                                subsense.get('examples', [''])[0]
                                if subsense.get('examples')
                                else ''
                            ),
                            'synonyms': subsense.get('synonyms', []),
                            'antonyms': subsense.get('antonyms', [])
                        })

            if definitions:
                meanings.append({
                    'partOfSpeech': entry.get(
                        'partOfSpeech', 'Meaning'
                    ),
                    'definitions': definitions
                })

        if not meanings:
            return response(404, {
                'message': 'No definitions available for this word.'
            })

        first_definition = meanings[0]['definitions'][0]['definition']

        timestamp = datetime.now(timezone.utc).isoformat()

        table.put_item(
            Item={
                'userId': 'guest001',
                'searchedAt': timestamp,
                'word': data.get('word', word),
                'definition': first_definition,
                'language': language,
                'languageName': language_name,
                'type': 'dictionary'
            }
        )

        return response(200, {
            'word': data.get('word', word),
            'language': language,
            'languageName': language_name,
            'phonetic': phonetic,
            'meanings': meanings,
            'source': data.get('source', {})
        })

    except urllib.error.HTTPError as e:

        print('Dictionary API HTTP Error:', e.code)

        if e.code == 404:
            return response(404, {
                'message': 'Word not found in this language.'
            })

        if e.code == 429:
            return response(503, {
                'message': 'Dictionary API rate limit reached. Please try again later.'
            })

        return response(502, {
            'message': 'Dictionary API request failed.'
        })

    except urllib.error.URLError as e:

        print('Dictionary API URL Error:', str(e))

        return response(502, {
            'message': 'Dictionary service unavailable.'
        })

    except Exception as e:

        print('Search Error:', str(e))
        print('Exception type:', type(e).__name__)

        return response(500, {
            'message': 'Failed to process dictionary request.'
        })


def translate_text(data):

    text = data.get('text', '')
    source_language = data.get('sourceLanguage', 'auto')
    target_language = data.get('targetLanguage', '')
    user_id = data.get('userId', 'guest001')

    if not isinstance(text, str) or not text.strip():
        return response(400, {
            'message': 'Please provide text to translate.'
        })

    text = text.strip()

    if len(text) > 5000:
        return response(400, {
            'message': 'Text cannot exceed 5000 characters.'
        })

    if not isinstance(target_language, str):
        return response(400, {
            'message': 'Invalid target language.'
        })

    target_language = target_language.strip().lower()

    if target_language not in LANGUAGE_NAMES:
        return response(400, {
            'message': 'Unsupported target language.'
        })

    if not isinstance(source_language, str):
        return response(400, {
            'message': 'Invalid source language.'
        })

    source_language = source_language.strip().lower()

    if source_language != 'auto' and source_language not in LANGUAGE_NAMES:
        return response(400, {
            'message': 'Unsupported source language.'
        })

    try:
        detected_language = source_language

        if source_language == 'auto':

            detection = comprehend_client.detect_dominant_language(
                Text=text
            )

            languages = detection.get('Languages', [])

            if not languages:
                return response(400, {
                    'message': 'Unable to detect the source language.'
                })

            detected_language = languages[0].get('LanguageCode')

            if not detected_language:
                return response(400, {
                    'message': 'Unable to detect the source language.'
                })

        if detected_language == target_language:
            return response(400, {
                'message': 'Source and target languages are the same.'
            })

        result = translate_client.translate_text(
            Text=text,
            SourceLanguageCode=detected_language,
            TargetLanguageCode=target_language
        )

        translated_text = result.get('TranslatedText', '')

        source_name = LANGUAGE_NAMES.get(
            detected_language, detected_language
        )

        target_name = LANGUAGE_NAMES.get(
            target_language, target_language
        )

        timestamp = datetime.now(timezone.utc).isoformat()

        table.put_item(
            Item={
                'userId': user_id,
                'searchedAt': timestamp,
                'type': 'translation',
                'word': text,
                'definition': translated_text,
                'language': target_language,
                'languageName': target_name,
                'sourceLanguage': detected_language,
                'sourceLanguageName': source_name,
                'translatedText': translated_text
            }
        )

        return response(200, {
            'originalText': text,
            'translatedText': translated_text,
            'sourceLanguage': detected_language,
            'sourceLanguageName': source_name,
            'targetLanguage': target_language,
            'targetLanguageName': target_name
        })

    except ClientError as e:

        error_code = e.response.get(
            'Error', {}
        ).get('Code', 'Unknown')

        print('AWS Translation Error:', error_code)
        print('AWS Translation Details:', str(e))

        if error_code in (
            'UnsupportedLanguagePairException',
            'UnsupportedLanguageException'
        ):
            return response(400, {
                'message': 'This language combination is not supported.'
            })

        if error_code in (
            'TextSizeLimitExceededException',
            'InvalidRequestException'
        ):
            return response(400, {
                'message': 'The translation request is invalid or exceeds service limits.'
            })

        if error_code in (
            'DetectedLanguageLowConfidenceException',
            'UnsupportedLanguageException'
        ):
            return response(400, {
                'message': 'Unable to detect or translate this source language.'
            })

        return response(502, {
            'message': 'AWS translation service failed. Please try again.'
        })

    except Exception as e:

        print('Translation Error:', str(e))
        print('Exception type:', type(e).__name__)

        return response(500, {
            'message': 'Failed to process translation request.'
        })


def response(status_code, body):

    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(body, default=str)
    }