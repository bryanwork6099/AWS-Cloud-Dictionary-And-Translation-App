import json
import boto3
import urllib.request
import urllib.error
import urllib.parse
import os
import re

from datetime import datetime, timezone
from boto3.dynamodb.conditions import Key

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['TABLE_NAME'])

DICTIONARY_API = 'https://freedictionaryapi.com/api/v1'


def lambda_handler(event, context):
    try:
        method = event.get('requestContext', {}).get(
            'http', {}
        ).get('method', 'GET')

        if method == 'GET':
            params = event.get('queryStringParameters') or {}

            word = params.get('word')
            language = params.get('language', 'en')

            if not word or not word.strip():
                return response(400, {
                    'message': 'Please provide a word.'
                })

            word = word.strip()
            language = language.strip().lower()

            if not re.fullmatch(r'[a-z]{2,3}(?:-[a-z]{2,3})*', language):
                return response(400, {
                    'message': 'Invalid language code.'
                })

            return search_word(word, language)

        elif method == 'POST':
            params = event.get('queryStringParameters') or {}
            user_id = params.get('userId', 'guest001')

            result = table.query(
                KeyConditionExpression=Key('userId').eq(user_id),
                ScanIndexForward=False,
                Limit=20
            )

            return response(200, {
                'history': result.get('Items', [])
            })

        else:
            return response(405, {
                'message': 'Method not allowed.'
            })

    except Exception as e:
        print('Error:', str(e))
        print('Exception type:', type(e).__name__)

        return response(500, {
            'message': 'Internal server error.'
        })


def search_word(word, language):

    encoded_word = urllib.parse.quote(word, safe='')

    url = (
        f'{DICTIONARY_API}/entries/'
        f'{language}/{encoded_word}'
    )

    try:
        req = urllib.request.Request(
            url,
            headers={
                'User-Agent': 'CloudDictionaryApp/2.0',
                'Accept': 'application/json'
            }
        )

        with urllib.request.urlopen(req, timeout=15) as res:
            data = json.loads(res.read().decode())

        entries = data.get('entries', [])

        if not entries:
            return response(404, {
                'message': 'Word not found in this language.'
            })

        meanings = []
        phonetic = ''
        language_name = language

        for entry in entries:

            entry_language = entry.get('language', {})

            if isinstance(entry_language, dict):
                language_name = entry_language.get(
                    'name', language_name
                )

            if not phonetic:
                pronunciations = entry.get(
                    'pronunciations', []
                )

                for pronunciation in pronunciations:
                    if pronunciation.get('type') == 'ipa':
                        phonetic = pronunciation.get('text', '')
                        break

            definitions = []

            for sense in entry.get('senses', []):

                definition_text = sense.get('definition', '')

                if definition_text:
                    definitions.append({
                        'definition': definition_text,
                        'example': (
                            sense.get('examples', [''])[0]
                            if sense.get('examples')
                            else ''
                        ),
                        'synonyms': sense.get('synonyms', []),
                        'antonyms': sense.get('antonyms', [])
                    })

                for subsense in sense.get('subsenses', []):
                    sub_definition = subsense.get(
                        'definition', ''
                    )

                    if sub_definition:
                        definitions.append({
                            'definition': sub_definition,
                            'example': (
                                subsense.get('examples', [''])[0]
                                if subsense.get('examples')
                                else ''
                            ),
                            'synonyms': subsense.get('synonyms', []),
                            'antonyms': subsense.get('antonyms', [])
                        })

            if definitions:
                meanings.append({
                    'partOfSpeech': entry.get(
                        'partOfSpeech', 'Meaning'
                    ),
                    'definitions': definitions
                })

        if not meanings:
            return response(404, {
                'message': 'No definitions available for this word.'
            })

        first_definition = meanings[0]['definitions'][0]['definition']

        timestamp = datetime.now(timezone.utc).isoformat()

        table.put_item(
            Item={
                'userId': 'guest001',
                'searchedAt': timestamp,
                'word': data.get('word', word),
                'definition': first_definition,
                'language': language,
                'languageName': language_name
            }
        )

        return response(200, {
            'word': data.get('word', word),
            'language': language,
            'languageName': language_name,
            'phonetic': phonetic,
            'meanings': meanings,
            'source': data.get('source', {})
        })

    except urllib.error.HTTPError as e:

        print('Dictionary API HTTP Error:', e.code)

        if e.code == 404:
            return response(404, {
                'message': 'Word not found in this language.'
            })

        if e.code == 429:
            return response(503, {
                'message': 'Dictionary API rate limit reached. Please try again later.'
            })

        return response(502, {
            'message': 'Dictionary API request failed.'
        })

    except urllib.error.URLError as e:

        print('Dictionary API URL Error:', str(e))

        return response(502, {
            'message': 'Dictionary service unavailable.'
        })

    except Exception as e:

        print('Search Error:', str(e))
        print('Exception type:', type(e).__name__)

        return response(500, {
            'message': 'Failed to process dictionary request.'
        })


def response(status_code, body):

    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(body, default=str)
    }